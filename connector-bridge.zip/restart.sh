#!/bin/sh

cd mds
./restart.sh
cd ${HOME}
