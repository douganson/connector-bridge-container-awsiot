#!/bin/sh

rm -f ./logs/*.log 2> /dev/null
mkdir -p ./logs
cd ${HOME}/service/target
java -Dconfig_file="../conf/service.properties" -jar connector-bridge-1.0.war > ../logs/connector-bridge.log 2>&1
